package com.example.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Random;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

@RestController
public class MeetingController {

    private static final Log log = LogFactory.getLog(MeetingController.class);

    Random r = new Random();

    @GetMapping("/meet")
    public String meeting() {
        try {
            log.info("meeting...");
            Thread.sleep(r.nextInt(500 - 20 + 1) + 20);
        } catch (InterruptedException e) {
        }
        return "finished meeting";
    }
}
