package com.example.demo;

import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.Random;

@RestController
public class WorkController {

    @Autowired
    RestTemplate restTemplate;

    private static final Log log = LogFactory.getLog(WorkController.class);
    Random r = new Random();

    public void meeting() {
      /*  try {
            log.info("meeting...");
            // Delay for random number of milliseconds.
            Thread.sleep(r.nextInt(500));
        } catch (InterruptedException e) {
        }*/
        //commented the above code for testing service to service interaction
        String result = restTemplate.getForObject("http://localhost:8081/meet", String.class);
        log.info(result);
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/api/posts")
    public String work() {
        // What is work? Meetings!
        // When you hit this URL, it'll call meetings() 5 times.
        // Each time will have a random delay.
        log.info("starting to work");
        for (int i = 0; i < 5; i++) {
            this.meeting();
        }
        log.info("finished!");
        return "finished work!";
    }

    @Bean
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }
}
